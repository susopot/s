import discord
from discord.ext import commands
import re
import unicodedata
import json
import asyncio
from datetime import datetime, timedelta
import os
from dotenv import load_dotenv
from typing import Optional

# Load environment variables from .env file
load_dotenv()

# Bot setup with necessary intents
intents = discord.Intents.default()
intents.messages = True
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents)

# Configuration
ANTI_SPAM_CHANNEL_ID = 1352874878298099712

# Bypass role IDs - users with these roles will bypass all filters
BYPASS_ROLE_IDS = [1353000809171783752, 1417111559075004488, 1356539491090694198]

def is_stylized_unicode(text):
    """
    Detect stylized Unicode characters (mathematical symbols, fancy fonts, etc.)
    Only catches spam patterns, allows normal emojis and text
    """
    # Only Mathematical Alphanumeric Symbols (the main spam pattern)
    # This catches ℝ, 𝕌, 𝔼, ℕ, etc. but not normal emojis
    mathematical_pattern = r'[\U0001D400-\U0001D7FF]+'
    
    return bool(re.search(mathematical_pattern, text))

def is_zalgo_text(text):
    """
    Detect Zalgo text by checking for excessive combining characters
    """
    combining_chars = 0
    total_chars = len(text)
    
    if total_chars == 0:
        return False
    
    for char in text:
        if unicodedata.combining(char):
            combining_chars += 1
    
    # If more than 30% of characters are combining characters, it's likely Zalgo
    ratio = combining_chars / total_chars
    return ratio > 0.3 or combining_chars > 10

def contains_blocked_patterns(text):
    """
    Check for specific blocked message patterns
    """
    # Pattern from the user's example
    blocked_patterns = [
        r'ℝ𝕌:.*𝕙𝕥𝕥𝕡𝕤://.*𝕥𝕖𝕝𝕖𝕘𝕣𝕒\.𝕡𝕙/',
        r'𝔼ℕ:.*𝕙𝕥𝕥𝕡𝕤://.*𝕥𝕖𝕝𝕖𝕘𝕣𝕒\.𝕡𝕙/',
        r'𝔸𝕟𝕥𝕚-𝕛𝕚𝕒𝕟𝕝𝕨',
        r'𝔸𝕟𝕥𝕚-𝔸𝕟𝕥𝕚-𝕁𝕚𝕒𝕟𝕝𝕨'
    ]
    
    for pattern in blocked_patterns:
        if re.search(pattern, text, re.IGNORECASE):
            return True
    
    return False

def should_bypass_filters(message):
    """
    Check if message should bypass all filters
    """
    # Always bypass bot messages
    if message.author.bot:
        return True
    
    # Bypass if user has bypass roles
    if hasattr(message.author, 'roles'):  # Guild member
        member_role_ids = [role.id for role in message.author.roles]
        return any(role_id in member_role_ids for role_id in BYPASS_ROLE_IDS)
    
    return False

async def log_blocked_message(message, reason):
    """
    Log blocked message to anti-spam channel
    """
    try:
        anti_spam_channel = bot.get_channel(ANTI_SPAM_CHANNEL_ID)
        if anti_spam_channel and isinstance(anti_spam_channel, discord.TextChannel):
            embed = discord.Embed(
                title="🚫 Blocked Message",
                color=discord.Color.red(),
                timestamp=datetime.utcnow()
            )
            embed.add_field(name="User", value=f"{message.author.mention} ({message.author.id})", inline=False)
            embed.add_field(name="Channel", value=f"{message.channel.mention}", inline=False)
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Content", value=f"```{message.content[:1000]}```", inline=False)
            
            await anti_spam_channel.send(embed=embed)
            
            # Simple notification that message was deleted
            await anti_spam_channel.send(
                f"🗑️ **Deleted spam message** from {message.author.mention} in {message.channel.mention}"
            )
    except Exception as e:
        print(f"Error logging blocked message: {e}")

# Strike and mute system removed - bot now only deletes spam messages and logs them

@bot.event
async def on_ready():
    print(f'{bot.user} has connected to Discord!')
    print(f'Bot is monitoring {len(bot.guilds)} server(s)')

@bot.event
async def on_message(message):
    # Don't process bot's own messages
    if message.author == bot.user:
        return
    
    # Skip DMs - only process guild messages
    if message.guild is None:
        return
    
    # Skip if should bypass filters (bots, owner/admin roles)
    if should_bypass_filters(message):
        await bot.process_commands(message)
        return
    
    # Check if message should be blocked
    blocked = False
    reason = ""
    
    # Block stylized Unicode (mathematical symbols used in spam)
    if is_stylized_unicode(message.content):
        blocked = True
        reason = "Stylized Unicode characters detected"
    # Block Zalgo text (excessive combining characters)
    elif is_zalgo_text(message.content):
        blocked = True
        reason = "Zalgo text detected"
    # Block specific spam patterns
    elif contains_blocked_patterns(message.content):
        blocked = True
        reason = "Spam pattern detected"
    
    if blocked:
        try:
            # Delete the message
            await message.delete()
            
            # Log the blocked message (no strikes or mutes)
            await log_blocked_message(message, reason)
        
        except discord.errors.NotFound:
            # Message was already deleted
            pass
        except Exception as e:
            print(f"Error processing blocked message: {e}")
    
    # Process commands
    await bot.process_commands(message)

# Strike commands removed - bot now only deletes and logs spam patterns

# Run the bot
if __name__ == "__main__":
    # Load token from environment variable for security
    TOKEN = os.getenv('DISCORD_TOKEN')
    if not TOKEN:
        print("❌ ERROR: DISCORD_TOKEN environment variable not set!")
        print("Please create a .env file with DISCORD_TOKEN=your_bot_token")
        print("For security reasons, tokens should not be hardcoded in the source code.")
        exit(1)
    
    try:
        print("Starting Discord bot...")
        print("Note: If you get a PrivilegedIntentsRequired error, you need to:")
        print("1. Go to https://discord.com/developers/applications/")
        print("2. Select your bot application")
        print("3. Go to the 'Bot' section")
        print("4. Enable 'Message Content Intent' under 'Privileged Gateway Intents'")
        print("5. Save changes and restart the bot")
        print()
        
        bot.run(TOKEN)
    except discord.errors.PrivilegedIntentsRequired:
        print("\n❌ ERROR: Privileged intents are required but not enabled!")
        print("Please enable 'Message Content Intent' in your Discord Developer Portal:")
        print("1. Go to https://discord.com/developers/applications/")
        print("2. Select your bot application")
        print("3. Go to the 'Bot' section")
        print("4. Enable 'Message Content Intent' under 'Privileged Gateway Intents'")
        print("5. Save changes and restart the bot")
    except discord.errors.LoginFailure:
        print("\n❌ ERROR: Invalid bot token!")
        print("Please check your bot token in the Discord Developer Portal.")
    except Exception as e:
        print(f"\n❌ ERROR: Failed to start bot: {e}")
        print("Please check your bot configuration and try again.")