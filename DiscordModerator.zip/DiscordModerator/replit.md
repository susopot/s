# Overview

This is a Discord moderation bot designed to combat spam and stylized Unicode abuse in Discord servers. The bot automatically detects and moderates users who send messages containing stylized Unicode characters (such as mathematical symbols and fancy fonts) that are commonly used for spam or to bypass content filters. It implements a strike system with escalating consequences including timeouts and automatic bans for repeat offenders.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Bot Framework
- **Discord.py Library**: Uses the discord.py library with the commands extension for bot functionality
- **Command Prefix**: Configured with '!' prefix for manual commands
- **Intents**: Enabled message and message content intents for reading and processing messages

## Moderation System
- **Anti-Spam Detection**: Real-time message scanning for stylized Unicode characters across multiple Unicode ranges (Mathematical Alphanumeric Symbols, Letterlike Symbols, Phonetic Extensions)
- **Strike System**: Progressive punishment system that tracks user violations with configurable thresholds
- **Automated Penalties**: Escalating consequences from timeouts to permanent bans based on strike count

## Data Persistence
- **JSON File Storage**: Simple file-based storage using strikes.json for tracking user violations
- **Synchronous I/O**: Load/save operations for strikes data with error handling for missing files
- **In-Memory Cache**: Runtime strikes dictionary for fast access during message processing

## Configuration Management
- **Environment Variables**: Uses python-dotenv for loading bot tokens and sensitive configuration
- **Hardcoded Constants**: Channel IDs, mute durations, and strike limits defined as module-level constants
- **Unicode Pattern Matching**: Regex patterns for detecting various stylized Unicode character ranges

## Event-Driven Architecture
- **Message Listeners**: Automatic processing of all incoming messages for moderation checks
- **Asynchronous Operations**: Discord API interactions handled asynchronously for performance
- **Error Handling**: Basic exception handling for file operations and API calls

# External Dependencies

## Discord Platform
- **Discord API**: Core platform integration for bot operations, message handling, and moderation actions
- **Discord Gateway**: Real-time message events and server interactions

## Python Libraries
- **discord.py**: Primary Discord bot framework with commands extension
- **python-dotenv**: Environment variable management for configuration
- **asyncio**: Asynchronous programming support for Discord operations
- **re**: Regular expression engine for Unicode pattern detection
- **unicodedata**: Unicode character analysis and normalization
- **json**: Data serialization for strikes persistence
- **datetime**: Time-based operations for mute durations and timestamps

## File System
- **Local Storage**: JSON file persistence for user strikes data
- **Environment File**: .env file for secure configuration storage